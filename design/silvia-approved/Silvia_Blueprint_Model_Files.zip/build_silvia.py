import bpy, bmesh, math, os, json
from mathutils import Vector
from math import sin, cos, pi
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'output')
os.makedirs(OUT,exist_ok=True)
bpy.ops.object.select_all(action='SELECT');bpy.ops.object.delete(use_global=False)
for block in bpy.data.materials: bpy.data.materials.remove(block)
CAR=bpy.data.collections.new('SILVIA_BLUEPRINT_REVIEW');bpy.context.scene.collection.children.link(CAR)
def car(obj):
 for c in list(obj.users_collection):c.objects.unlink(obj)
 CAR.objects.link(obj);return obj

def mat(name,c,metal=0,rough=.3,trans=0):
 m=bpy.data.materials.new(name);m.diffuse_color=(*c,1);m.use_nodes=True;p=m.node_tree.nodes.get('Principled BSDF');p.inputs['Base Color'].default_value=(*c,1);p.inputs['Metallic'].default_value=metal;p.inputs['Roughness'].default_value=rough;p.inputs['Transmission Weight'].default_value=trans
 return m
paint=mat('Pearl silver — neutral review finish',(.48,.52,.55),.68,.24)
p=paint.node_tree.nodes.get('Principled BSDF');p.inputs['Coat Weight'].default_value=.38;p.inputs['Coat Roughness'].default_value=.19
trim=mat('Window seals / moulding',(.012,.016,.019),.05,.35)
rubber=mat('Tyre rubber',(.018,.021,.023),0,.68)
groove=mat('Tread recess',(.005,.006,.007),0,.8)
glass=mat('Smoked automotive glass',(.045,.075,.09),0,.09,.72)
chrome=mat('Polished aluminium',(.66,.7,.73),.94,.19)
rim=mat('Machined silver spokes',(.53,.57,.61),.86,.24)
disc=mat('Brake rotors',(.24,.27,.29),.82,.43)
black=mat('Recess / cabin',(.008,.011,.014),.08,.47)
seatmat=mat('Cloth interior',(.028,.034,.039),0,.8)
red=mat('Red tail-light lens',(.43,.011,.016),.27,.2)
clear=mat('Optical clear lens',(.70,.76,.78),0,.12,.75)
white=mat('Plate / lettering',(.8,.83,.78),.05,.42)
amber=mat('Corner reflector',(.55,.22,.035),.15,.22)
caliper=mat('Brake calipers',(.075,.084,.09),.6,.32)

def mesh(name,verts,faces,material=paint,smooth=True):
 me=bpy.data.meshes.new(name);me.from_pydata(verts,[],faces);me.update();bm=bmesh.new();bm.from_mesh(me);bmesh.ops.recalc_face_normals(bm,faces=bm.faces);bm.to_mesh(me);bm.free();o=bpy.data.objects.new(name,me);CAR.objects.link(o);o.data.materials.append(material)
 if smooth:
  for p in me.polygons:p.use_smooth=True
 return o

def bevel(o,width=.01,segments=3):
 m=o.modifiers.new('Manufactured edge radii','BEVEL');m.width=width;m.segments=segments
 return o

def cube(name,loc,dim,material=paint,r=.01):
 bpy.ops.mesh.primitive_cube_add(size=1,location=loc);o=car(bpy.context.object);o.name=name;o.dimensions=dim;bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);o.data.materials.append(material)
 if r:bevel(o,r,3)
 return o

def uv(name,loc,scale,material=paint):
 bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,radius=1,location=loc);o=car(bpy.context.object);o.name=name;o.scale=scale;o.data.materials.append(material)
 for p in o.data.polygons:p.use_smooth=True
 return o

def cyl(name,loc,radius,depth,material=chrome,axis='Y',vertices=64):
 rot=(pi/2,0,0) if axis=='Y' else ((0,pi/2,0) if axis=='X' else (0,0,0));bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc,rotation=rot);o=car(bpy.context.object);o.name=name;o.data.materials.append(material);bevel(o,.002,2)
 for p in o.data.polygons:p.use_smooth=True
 return o

def tube(name,points,r=.002,material=trim,cyclic=False,res=3):
 cv=bpy.data.curves.new(name,'CURVE');cv.dimensions='3D';cv.resolution_u=12;cv.bevel_depth=r;cv.bevel_resolution=res;s=cv.splines.new('POLY');s.points.add(len(points)-1)
 for p,co in zip(s.points,points):p.co=(*co,1)
 s.use_cyclic_u=cyclic;o=bpy.data.objects.new(name,cv);CAR.objects.link(o);o.data.materials.append(material);return o

def surface(name,fn,nu=32,nv=20,material=paint):
 v=[fn(i/nu,j/nv) for i in range(nu+1) for j in range(nv+1)];f=[]
 for i in range(nu):
  for j in range(nv):a=i*(nv+1)+j;f.append((a,a+nv+1,a+nv+2,a+1))
 return mesh(name,v,f,material)

def interp(points,x):
 for i in range(len(points)-1):
  if x<=points[i+1][0]:
   t=max(0,min(1,(x-points[i][0])/(points[i+1][0]-points[i][0])));t=t*t*(3-2*t);return points[i][1]*(1-t)+points[i+1][1]*t
 return points[-1][1]
W=[(-2.32,.74),(-2.24,.82),(-2,.862),(-1.3,.884),(-.8,.861),(0,.855),(.65,.864),(1.22,.886),(1.8,.875),(2.2,.854),(2.32,.82)]
H=[(-2.32,.636),(-2.2,.71),(-1.8,.765),(-1.25,.788),(-.8,.793),(.2,.787),(1.25,.789),(1.7,.794),(2.15,.789),(2.32,.74)]
xs=[-2.32+4.64*i/160 for i in range(161)]
# Rounded shoulder, crisp belt line and a subtly tucked lower body.
profile=[(0,1),(.30,1),(.60,.997),(.82,.986),(.93,.94),(.985,.85),(1,.74),(1,.60),(.992,.44),(.98,.28),(.95,.18),(.85,.16),(0,.16)]
verts=[]
for x in xs:
 w=interp(W,x);h=interp(H,x)
 # Top half, right side then underside and left side: a closed body cross-section.
 ring=profile+ [(-y,z) for y,z in profile[-2:0:-1]]
 for y,q in ring:
  z=.16+(h-.16)*q if q>.2 else q
  if q>.94:z+=.017*(1-(abs(y))**2)
  verts.append((x,y*w,z))
n=len(ring);faces=[]
for i in range(len(xs)-1):
 for j in range(n):a=i*n+j;b=i*n+(j+1)%n;faces.append((a,b,b+n,a+n))
faces += [tuple(range(n-1,-1,-1)),tuple((len(xs)-1)*n+j for j in range(n))]
body=mesh('Sculpted body shell',verts,faces)
# Actual wheel openings, not black circles painted on a solid body.
for axle,x in [('Front',-1.30),('Rear',1.22)]:
 cut=cyl('temporary arch cutter',(x,0,.335),.371,3,black,vertices=128)
 for mo in list(cut.modifiers):cut.modifiers.remove(mo)
 bpy.context.view_layer.objects.active=body;m=body.modifiers.new(axle+' wheel opening','BOOLEAN');m.object=cut;m.operation='DIFFERENCE';m.solver='EXACT';bpy.ops.object.modifier_apply(modifier=m.name);bpy.data.objects.remove(cut,do_unlink=True)
# Open the lamp band and the cabin tub in the actual shell.
for name,loc,dims in [('Lamp recess',(-2.30,0,.616),(.43,1.63,.13)),('Cabin opening',(.35,0,1.02),(1.88,1.18,.66))]:
 cut=cube('Temporary '+name,loc,dims,black,0);bpy.context.view_layer.objects.active=body;m=body.modifiers.new(name,'BOOLEAN');m.object=cut;m.operation='DIFFERENCE';bpy.ops.object.modifier_apply(modifier=m.name);bpy.data.objects.remove(cut,do_unlink=True)
bevel(body,.004,2)
# Shaped, rolled fender lips trace the wheel openings.
for x in [-1.30,1.22]:
 for side in [-1,1]:
  def arch(u,v):
   a=pi*u;r=.373+.047*v;xx=x+r*cos(a);z=.335+r*sin(a);yy=interp(W,xx)*(1-.12*(v*v*(3-2*v)))+.005+.009*sin(pi*v);return(xx,side*yy,z)
  surface('Rolled wheel arch',arch,72,7)
  tube('Arch edge',[(x+.372*cos(pi*i/80),side*(interp(W,x+.372*cos(pi*i/80))+.009),.335+.372*sin(pi*i/80)) for i in range(81)],.003,paint)
# Sculpted side skirts with raised ends and a straight lower sill.
for side in [-1,1]:
 def skirt(u,v):
  x=-.93+1.81*u;upper=.25+.10*(abs(2*u-1)**5);lower=.092+.025*(1-abs(2*u-1));y=.838+.035*sin(pi*v)+.025*abs(2*u-1)**4;return(x,side*y,upper*(1-v)+lower*v)
 surface('Deep side skirt',skirt,58,10)
 tube('Side skirt lower edge',[(-.94+1.82*i/80,side*(.867+.025*abs(2*i/80-1)**4),.09+.026*(1-abs(2*i/80-1))) for i in range(81)],.006,paint)
 tube('Lower sill crease',[(-.85+1.62*i/60,side*.861,.246) for i in range(61)],.0024,trim)
# Front bumper: real recessed rectangular apertures and a wrapped aero corner.
front=cube('Deep front bumper',(-2.255,0,.298),(.22,1.72,.416),paint,.025)
def hole(o,loc,dim,r=.012):
 c=cube('temporary aperture',loc,dim,black,r);bpy.context.view_layer.objects.active=c
 for mod in list(c.modifiers):bpy.ops.object.modifier_apply(modifier=mod.name)
 bpy.context.view_layer.objects.active=o;m=o.modifiers.new('Open aperture','BOOLEAN');m.object=c;m.operation='DIFFERENCE';m.solver='EXACT';bpy.ops.object.modifier_apply(modifier=m.name);bpy.data.objects.remove(c,do_unlink=True)
for y in [-.575,.575]:
 hole(front,(-2.26,y,.237),(.6,.34,.135))
 cube('Recessed intake shadow',(-2.334,y,.237),(.015,.322,.119),black,.008)
 for j in range(7):cube('Intercooler horizontal fin',(-2.343,y,.188+j*.016),(.009,.296,.003),disc,.0007)
 for j in range(8):cube('Intake grille upright',(-2.350,y-.14+j*.04,.237),(.005,.003,.112),trim,.0005)
for side in [-1,1]:
 corner=cube('Front bumper wrap',(-1.98,side*.795,.298),(.60,.16,.39),paint,.025)
 # The side cooling duct is a recessed, raked opening as in the side drawing.
 poly=[(-2.015,side*.882,.145),(-1.805,side*.882,.145),(-1.725,side*.882,.475),(-1.885,side*.882,.453)]
 mesh('Angled side intake',poly,[(0,1,2,3)],black,False)
 tube('Side intake moulded edge',poly,.008,paint,True)
 for k in range(3):
  x=-1.98+.059*k;tube('Raked intake louvre',[(x,side*.893,.17),(x+.075,side*.893,.431)],.007,disc)
 cube('Front bumper small marker',(-2.374,side*.652,.424),(.007,.102,.060),clear,.006)
 cube('Front marker frame',(-2.37,side*.652,.424),(.006,.119,.077),trim,.005)
# Lip and fine mouldings.
cube('Front splitter',(-2.286,0,.091),(.235,1.77,.032),paint,.008)
cube('Front lip shadow',(-2.402,0,.123),(.012,1.72,.009),trim,.002)
cube('Front plate plinth',(-2.383,0,.317),(.018,.58,.202),trim,.006)
cube('Japanese front plate',(-2.396,0,.319),(.009,.292,.155),white,.004)
# Flat, stepped lamp band and central slatted grille.
cube('Headlamp surround',(-2.224,0,.622),(.064,1.6,.128),trim,.012)
cube('Nose upper painted brow',(-2.269,0,.672),(.047,1.62,.016),paint,.011)
cube('Nose lower lamp lip',(-2.271,0,.554),(.042,1.63,.023),paint,.009)
for side in [-1,1]:
 v=[(-2.295,side*.784,.559),(-2.295,side*.784,.674),(-2.11,side*.851,.676),(-2.105,side*.86,.565),(-2.24,side*.825,.544)]
 o=mesh('Blended nose corner',v,[(0,1,2,3,4)],paint);m=o.modifiers.new('Corner thickness','SOLIDIFY');m.thickness=.012;bevel(o,.005)

for side in [-1,1]:
 y=side*.515
 cube('Headlight optical housing',(-2.261,y,.625),(.025,.514,.095),chrome,.012)
 for j in range(3):
  yy=side*(.318+j*.155)
  cube('Headlight reflector chamber',(-2.28,yy,.628),(.012,.136,.067),clear,.009)
  for k in range(6):cube('Fluted headlamp optic',(-2.289,yy-.055+k*.022,.628),(.002,.0012,.058),chrome,.0003)
 cube('Continuous headlamp outer lens',(-2.294,side*.515,.625),(.005,.513,.091),clear,.008)
 cube('Corner clear indicator',(-2.261,side*.795,.625),(.022,.064,.09),clear,.008)
 # Small amber insert remains behind the mostly clear corner lens.
 cube('Indicator reflector insert',(-2.265,side*.812,.623),(.01,.018,.064),amber,.002)
for z in [.59,.612,.634]:cube('Central grille slat',(-2.285,0,z),(.016,.48,.006),disc,.001)
# Hood seams and raised longitudinal swages follow the front/top projections.
for side in [-1,1]:
 pts=[];crease=[]
 for i in range(90):
  t=i/89;x=-2.16+1.36*t;y=.59+.12*t;h=interp(H,x)+.008;pts.append((x,side*y,h));crease.append((x,side*(.32+.20*t),interp(H,x)+.021))
 tube('Bonnet panel gap',pts,.0017,trim);tube('Bonnet stamped swage',crease,.003,paint)
tube('Bonnet trailing seam',[(-.805-.032*(1-u*u),.707*u,.805) for u in [i/40 for i in range(-40,41)]],.0018,trim)
# Glazing patches: curved windscreen, crowned roof, swept rear screen.
def ws(u,v):
 q=2*v-1;xb=-.855+.085*q*q;xt=-.18-.10*q*q;return(xb*(1-u)+xt*u,(.728*(1-u)+.585*u)*q,.803*(1-u)+(1.248-.046*q*q)*u+.006*sin(pi*u))
def rs(u,v):
 q=2*v-1;xt=.90-.08*q*q;xb=1.65-.10*q*q;return(xt*(1-u)+xb*u,(.59*(1-u)+.73*u)*q,(1.245-.045*q*q)*(1-u)+.799*u+.008*sin(pi*u))
surface('Curved front windscreen',ws,28,44,glass)
surface('Swept rear windscreen',rs,24,44,glass)
def roof(u,v):
 q=2*v-1;return((-.18-.10*q*q)*(1-u)+(.90-.08*q*q)*u,(.585*(1-u)+.59*u)*q,1.248-.046*q*q+.009*sin(pi*u))
surface('Crowned roof panel',roof,42,36)
for name,fn in [('Windscreen',ws),('Rear glass',rs)]:
 for edge in [0,1]:tube(name+' rubber perimeter',[fn(edge,i/60) for i in range(61)],.008,trim)
 for edge in [0,1]:tube(name+' side perimeter',[fn(i/50,edge) for i in range(51)],.011,trim)
# Side windows and painted A/C pillars have their own geometry, not one black canopy.
for side in [-1,1]:
 def p(x,y,z):return(x,side*y,z)
 A0=p(-.77,.729,.803);A1=p(-.28,.585,1.202);C0=p(1.55,.73,.799);C1=p(.82,.59,1.20)
 # Fine painted A pillars.
 tube('Painted A pillar',[A0, p(-.70,.725,.862), p(-.29,.593,1.202)],.023,paint)
 main=[p(-.675,.754,.817),p(-.244,.607,1.196),p(.49,.612,1.196),p(.455,.771,.817)]
 quarter=[p(.552,.771,.818),p(.565,.610,1.196),p(.692,.619,1.168),p(1.117,.754,.818)]
 # Slightly convex side glass.
 def window(points,name):
  a,b,c,d=map(Vector,points)
  def f(u,v):
   pos=a*(1-u)*(1-v)+b*u*(1-v)+c*u*v+d*(1-u)*v;pos.y+=side*.006*sin(pi*u)*sin(pi*v);return tuple(pos)
  surface(name,f,16,22,glass);tube(name+' seal',points,.008,trim,True)
 window(main,'Door side glass');window(quarter,'Rear quarter glass')
 # Pillar width and fixed rear triangle follow the side-view drawing.
 mesh('B pillar', [p(.49,.612,1.20),p(.565,.610,1.20),p(.552,.776,.799),p(.455,.776,.799)],[(0,1,2,3)],trim,False)
 cp=[C1,C0,p(1.117,.759,.799),p(.692,.624,1.18)]
 mesh('Wide painted C pillar',cp,[(0,1,2,3)],paint)
 tube('Roof side rail',[p(-.29,.593,1.205),p(.1,.597,1.206),p(.52,.600,1.206),p(.82,.600,1.201)],.012,paint)
 tube('Window waist seal',[p(-.77,.759,.80),p(.47,.778,.80),p(1.18,.756,.80),p(1.55,.737,.80)],.008,trim)
 # Door shut line and recessed door handle.
 door=[p(-.75,.862,.778),p(-.83,.865,.59),p(-.83,.855,.32),p(-.67,.855,.258),p(.28,.858,.258),p(.46,.866,.33),p(.53,.873,.51),p(.53,.865,.78)]
 tube('Door panel shut line',door,.0018,trim)
 cube('Recessed handle pocket',p(.36,.875,.665),(.17,.011,.044),trim,.009)
 cube('Body-colour handle',p(.35,.884,.675),(.14,.014,.023),paint,.007)
 # Belt-line crease remains subtle in the neutral paint.
 
 for start,end in [(-2.12,-1.65),(-.94,.85),(1.61,2.24)]:tube('Shoulder belt moulding',[(x,side*(interp(W,x)+.001),.594) for x in [start+(end-start)*i/45 for i in range(46)]],.0028,trim)
 # Door mirrors with separate glass and a narrow stalk.
 tube('Mirror mounting stalk',[p(-.645,.739,.82),p(-.61,.889,.84),p(-.57,.943,.84)],.014,trim)
 base=[(-.65,.929),(-.646,1.017),(-.574,1.046),(-.493,1.016),(-.486,.929)]
 vv=[p(x,y,z) for z in [.811,.877] for x,y in base];n=len(base);ff=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
 bevel(mesh('Shaped door mirror',vv,ff,paint),.017,4)
 cube('Mirror reflective face',p(-.478,.969,.843),(.007,.079,.042),chrome,.008)
# Rear bumper and skirts.
rear=cube('Rear bumper cover',(2.265,0,.33),(.19,1.74,.31),paint,.025)
hole(rear,(2.30,-.57,.135),(.55,.16,.17),.035)
for side in [-1,1]:
 v=[(1.64,side*.878,.273),(1.70,side*.883,.458),(2.28,side*.869,.458),(2.352,side*.845,.388),(2.332,side*.858,.270)]
 o=mesh('Rear bumper moulded wrap',v,[(0,1,2,3,4)],paint);m=o.modifiers.new('Rear wrap thickness','SOLIDIFY');m.thickness=.024;bevel(o,.012)
 poly=[(1.62,side*.88,.10),(2.32,side*.86,.19),(2.32,side*.86,.28),(1.63,side*.88,.29)]
 mesh('Rear lower aero skirt',poly,[(0,1,2,3)],paint,False)
 tube('Rear bumper moulding',[(2.366,-.83,.39),(2.369,0,.39),(2.366,.83,.39)],.004,trim)
cube('Rear plate recess',(2.368,0,.31),(.018,.35,.185),trim,.008)
cube('Japanese rear plate',(2.381,0,.31),(.009,.29,.154),white,.003)
cube('Lower rear valance shadow',(2.371,0,.179),(.015,1.22,.048),trim,.01)
# Long, stepped rear lamp units, centre script panel and boot details.
for side in [-1,1]:
 cube('Rear lamp gasket',(2.287,side*.505,.641),(.052,.548,.154),trim,.01)
 cube('Upper tail lamp red lens',(2.319,side*.505,.685),(.021,.509,.045),red,.007)
 cube('Reversing light strip',(2.322,side*.505,.643),(.021,.509,.022),clear,.004)
 cube('Lower tail lamp red lens',(2.321,side*.505,.605),(.022,.509,.035),red,.006)
 for j in range(10):cube('Rear lens prism',(2.336,side*.505-.23+j*.051,.685),(.001,.0016,.035),red,.0002)
cube('Rear centre lamp trim',(2.314,0,.643),(.028,.44,.12),trim,.006)
# Recessed boot lid lines.
tube('Boot lid lower seam',[(2.284,-.78,.751),(2.299,0,.758),(2.284,.78,.751)],.0018,trim)
for side in [-1,1]:tube('Boot lid side seam',[(1.65,side*.72,.802),(2.16,side*.75,.799),(2.28,side*.76,.751)],.0018,trim)
# Large wing, with sloped airfoil, shaped end plates and twin inclined mounts.
for side in [-1,1]:
 # Mount is angled rearward like the side blueprint.
 p=[(1.98,side*.45,.80),(2.09,side*.45,.805),(2.15,side*.45,1.044),(2.047,side*.45,1.026)]
 obj=mesh('Angled wing mount',p,[(0,1,2,3)],disc,False);mod=obj.modifiers.new('Mount thickness','SOLIDIFY');mod.thickness=.022;bevel(obj,.006)
 cube('Wing foot',(2.029,side*.45,.803),(.17,.065,.014),trim,.004)
def wing(u,v):
 y=(2*v-1)*.888;x=1.935+.355*u;z=1.045+.046*u+.023*sin(pi*u)-.006*(y/.888)**2;return(x,y,z)
w=surface('Raised rear airfoil',wing,28,42);m=w.modifiers.new('Airfoil thickness','SOLIDIFY');m.thickness=.018
for side in [-1,1]:
 p=[(1.914,side*.904,1.073),(2.267,side*.904,1.16),(2.294,side*.904,1.152),(2.288,side*.904,1.090),(2.229,side*.904,1.025),(1.969,side*.904,1.022)]
 o=mesh('Wing sculpted end plate',p,[tuple(range(6))],paint,False);m=o.modifiers.new('End plate thickness','SOLIDIFY');m.thickness=.012;bevel(o,.006)
# Single polished exhaust can, hollow outlet and rolled edge.
cyl('Rear exhaust can',(2.14,-.57,.135),.072,.31,disc,'X')
cyl('Polished exhaust tip',(2.285,-.57,.135),.060,.15,chrome,'X')
cyl('Exhaust bore',(2.364,-.57,.135),.048,.004,black,'X')
tube('Rolled exhaust rim',[(2.367,-.57+.055*cos(2*pi*i/80),.135+.055*sin(2*pi*i/80)) for i in range(80)],.004,chrome,True)
# Detailed five-spoke wheels, stepped polished lips, brake hardware and tread.
def lathe(name,cx,cy,cz,profile,material,segments=96):
 v=[];f=[]
 for yo,r in profile:
  for i in range(segments):a=2*pi*i/segments;v.append((cx+r*cos(a),cy+yo,cz+r*sin(a)))
 for j in range(len(profile)-1):
  for i in range(segments):a=j*segments+i;b=j*segments+(i+1)%segments;f.append((a,b,b+segments,a+segments))
 return mesh(name,v,f,material)
for axle,x in [('Front',-1.30),('Rear',1.22)]:
 for side in [-1,1]:
  cy=side*.79;cz=.335;wheel_before=set(CAR.objects)
  tireprofile=[(-.115,.244),(-.122,.265),(-.122,.300),(-.112,.324),(-.095,.333),(-.070,.337),(.070,.337),(.095,.333),(.112,.324),(.122,.300),(.122,.265),(.115,.244)]
  lathe(axle+' tyre',x,cy,cz,tireprofile,rubber,112)
  for yy,rr in [(side*.124,.289),(side*.124,.311),(side*.122,.251)]:
   tube('Tyre sidewall bead',[(x+rr*cos(2*pi*i/112),cy+yy,cz+rr*sin(2*pi*i/112)) for i in range(112)],.0013,rubber,True,1)
  # Swept grooves across the shoulder and tread; physically separate narrow recess lines.
  for k in range(72):
   a=2*pi*k/72
   for half in [-1,1]:
    pts=[]
    for j in range(6):
     t=j/5;yy=half*(.008+.091*t);theta=a+.05*t;rad=.338-.007*t**4;pts.append((x+rad*cos(theta),cy+yy,cz+rad*sin(theta)))
    tube('Directional tyre groove',pts,.00125,groove,False,1)
  # Barrel and stepped, deep-dish rim.
  prof=[(-side*.09,.249),(side*.09,.249),(side*.115,.254),(side*.126,.253),(side*.128,.245),(side*.117,.237),(side*.099,.227),(side*.077,.224)]
  lathe('Stepped polished rim',x,cy,cz,prof,chrome,112)
  lathe('Hollow inner rim barrel',x,cy,cz,[(-.09,.229),(.086,.229),(.086,.217),(-.09,.217),(-.09,.229)],disc,96)
  # Put the brake disc toward the car, spokes toward the outside.
  dy=cy+side*.048
  rotor=cyl('Ventilated brake rotor',(x,dy,cz),.199,.017,disc,'Y',96)
  for rr in [.14,.18,.194]:
   tube('Rotor machined ring',[(x+rr*cos(2*pi*i/96),dy+side*.010,cz+rr*sin(2*pi*i/96)) for i in range(96)],.0008,chrome,True,1)
  for j in range(28):
   a=2*pi*j/28
   cyl('Drilled rotor hole',(x+.165*cos(a),dy+side*.0105,cz+.165*sin(a)),.003,.002,black,'Y',8)
  cube('Brake caliper',(x+.15,dy+side*.016,cz+.045),(.057,.05,.15),caliper,.012)
  # Each spoke has a slightly swept shape and real concave depth.
  for k in range(5):
   a=2*pi*k/5+pi/2
   shape=[(.047,-.022),(.105,-.030),(.220,-.039),(.237,-.022),(.229,.012),(.145,.023),(.071,.030)]
   vs=[]
   for layer in [0,1]:
    for rr,tan in shape:
     xx=rr*cos(a)-tan*sin(a);zz=rr*sin(a)+tan*cos(a);yo=side*(.076+.036*(rr/.237)**1.3+layer*.016);vs.append((x+xx,cy+yo,cz+zz))
   n=len(shape);fs=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]+[(j,(j+1)%n,(j+1)%n+n,j+n) for j in range(n)]
   bevel(mesh('Swept five-spoke wheel',vs,fs,rim),.0055,3)
  cyl('Wheel centre cap',(x,cy+side*.103,cz),.050,.028,chrome,'Y',64)
  cyl('Centre badge',(x,cy+side*.12,cz),.025,.003,trim,'Y',48)
  for j in range(5):
   a=2*pi*j/5+pi/2;xx=x+.060*cos(a);zz=cz+.060*sin(a)
   cyl('Lug seat',(xx,cy+side*.101,zz),.013,.005,black,'Y',20)
   cyl('Hex wheel nut',(xx,cy+side*.109,zz),.009,.012,chrome,'Y',6)
  for o in set(CAR.objects)-wheel_before:o['assembly']=axle+(' left' if side<0 else ' right')
# Cabin depth: dashboard, seats, wheel, rear bench and interior floor.
cube('Cabin floor',(.38,0,.33),(2.04,1.40,.07),black,.015)
cube('Dashboard',(-.62,0,.70),(.31,1.39,.19),seatmat,.05)
cube('Dashboard top',(-.66,0,.798),(.30,1.40,.018),black,.01)
for side in [-1,1]:
 cube('Front seat cushion',(.10,side*.355,.49),(.48,.43,.15),seatmat,.065)
 o=cube('Front seat back',(.38,side*.355,.73),(.16,.44,.50),seatmat,.06);o.rotation_euler.y=-.15
 cube('Headrest',(.42,side*.355,1.00),(.13,.25,.16),seatmat,.045)
cube('Rear bench',(.96,0,.48),(.43,1.18,.17),seatmat,.05)
cube('Rear backrest',(1.21,0,.66),(.13,1.18,.36),seatmat,.04)
# Steering wheel in the left-hand position, visible through the windscreen.
tube('Steering wheel', [(-.37+.024*cos(2*pi*i/64),-.37+.125*cos(2*pi*i/64),.81+.125*sin(2*pi*i/64)) for i in range(64)],.012,trim,True)
for a in [pi/2,7*pi/6,11*pi/6]:tube('Steering wheel spoke',[(-.37,-.37,.81),(-.37,-.37+.115*cos(a),.81+.115*sin(a))],.009,trim)
cube('Centre console',(.02,0,.48),(.79,.16,.22),black,.02)
cyl('Shift lever',(.02,0,.67),.012,.18,chrome,'Z',20);uv('Shift knob',(.02,0,.77),(.026,.026,.033),trim)
# Fine markings: small original-style script, number plates, no invented body decals.
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
font=bpy.data.fonts.load(fontpath) if os.path.exists(fontpath) else None
def text(name,body,loc,size,rotation,material=white):
 cv=bpy.data.curves.new(name,'FONT');cv.body=body;cv.align_x='CENTER';cv.align_y='CENTER';cv.size=size;cv.extrude=.0002
 if font:cv.font=font
 o=bpy.data.objects.new(name,cv);CAR.objects.link(o);o.location=loc;o.rotation_euler=rotation;o.data.materials.append(material);return o
text('Silvia rear wordmark','S I L V I A',(2.335,0,.644),.030,(pi/2,0,pi/2),white)
for frontsign in [-1,1]:
 xx=-2.404 if frontsign<0 else 2.388
 # Text local XY plane is rotated to face the corresponding end of the car.
 rot=(pi/2,0,-pi/2) if frontsign<0 else (pi/2,0,pi/2)
 text('Registration main','13-13',(xx,0,.303),.046,rot,trim)
 text('Registration header','SILVIA',(xx,0,.351),.017,rot,trim)
# Wipers, glass frit and small boot lock.
for dy in [-.35,.27]:tube('Windscreen wiper',[(-.826,dy-.17,.815),(-.71,dy+.02,.846),(-.626,dy+.22,.899)],.004,trim)
cyl('Boot lock',(2.31,0,.772),.014,.005,chrome,'X',32)
# Finish the review model and export the exact geometry used by the renders.
bpy.ops.object.select_all(action='DESELECT')
for o in CAR.objects:o.select_set(True)
bpy.context.view_layer.objects.active=body
# Convert bevelled curves/text and apply modifiers for a portable, deterministic mesh.
bpy.ops.object.convert(target='MESH')
for o in CAR.objects:
 if o.type=='MESH':
  bpy.context.view_layer.objects.active=o
  for mod in list(o.modifiers):
   try:bpy.ops.object.modifier_apply(modifier=mod.name)
   except Exception:pass
# Match the blueprint's bumper-to-axle proportions without moving the axles,
# roof landmarks or circular wheel openings.
for o in CAR.objects:
 if o.type!='MESH':continue
 inv=o.matrix_world.inverted()
 # Add enough surface samples before bending the nose: large planar bumper
 # polygons otherwise fold along triangulation diagonals.
 bm=bmesh.new();bm.from_mesh(o.data)
 for step in range(6):
  edges=[e for e in bm.edges if max((o.matrix_world@v.co).x for v in e.verts)<-1.72 and (o.matrix_world.to_3x3()@(e.verts[0].co-e.verts[1].co)).length>.065]
  if not edges:break
  bmesh.ops.triangulate(bm,faces=list(bm.faces))
  edges=[e for e in bm.edges if max((o.matrix_world@v.co).x for v in e.verts)<-1.72 and (o.matrix_world.to_3x3()@(e.verts[0].co-e.verts[1].co)).length>.065]
  bmesh.ops.subdivide_edges(bm,edges=edges,cuts=1,use_grid_fill=True)
 bm.to_mesh(o.data);bm.free()
 if all((o.matrix_world@v.co).x<-1.70 for v in o.data.vertices):
  for p in o.data.polygons:p.use_smooth=True
 for v in o.data.vertices:
  p=o.matrix_world@v.co
  if p.x < -1.75:p.x=-1.75+(p.x+1.75)*(.570/.6535)
  elif p.x > 1.70:p.x=1.70+(p.x-1.70)*(.620/.670)
  # The supplied top view has a rounded nose, including its deep bumper.
  if p.x < -1.75:
   t=max(0,min(1,(-p.x-1.75)/.57));t=t*t*(3-2*t)
   p.x+=.185*(min(1,abs(p.y)/.89)**4)*t
  v.co=inv@p
 o.data.update()
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/Silvia_Blueprint_Review.blend')
# Same mesh surfaces, batched into material groups to keep the review responsive.
groups={}
for o in list(CAR.objects):
 if o.type=='MESH':groups.setdefault((o.get('assembly','Body'),o.data.materials[0].name if o.data.materials else ''),[]).append(o)
for (assembly,material),objects in groups.items():
 bpy.ops.object.select_all(action='DESELECT')
 for o in objects:o.select_set(True)
 bpy.context.view_layer.objects.active=objects[0]
 if len(objects)>1:bpy.ops.object.join()
 bpy.context.object.name=assembly+' / '+material
bpy.ops.object.select_all(action='DESELECT')
for o in CAR.objects:o.select_set(True)
bpy.ops.export_scene.gltf(filepath=OUT+'/Silvia_Blueprint_Review.glb',export_format='GLB',use_selection=True,export_apply=True,export_yup=True)
bpy.ops.wm.save_as_mainfile(filepath=OUT+'/Silvia_Blueprint_Review_Optimized.blend')
meshcount=sum(o.type=='MESH' for o in CAR.objects);triangles=0
for o in CAR.objects:
 if o.type=='MESH':o.data.calc_loop_triangles();triangles+=len(o.data.loop_triangles)
with open(OUT+'/model-info.json','w') as f:json.dump({'name':'Silvia — blueprint study 01','mesh_objects':meshcount,'triangles':triangles,'length_m':4.64,'wheelbase_m':2.52,'reference':'User-supplied four-view blueprint. Scale is inferred; the drawing contains no dimensions.','status':'Standalone approval asset. Not integrated into Drift Drive.'},f,indent=2)
# Studio render setup is deliberately not included in the exported GLB.
scene=bpy.context.scene;scene.render.engine='CYCLES';scene.cycles.samples=64;scene.cycles.use_denoising=False
scene.render.resolution_x=1600;scene.render.resolution_y=1000;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.world.color=(.20,.20,.20)
world=bpy.data.worlds.new('Neutral studio');world.use_nodes=True;world.node_tree.nodes['Background'].inputs[0].default_value=(.20,.23,.28,1);world.node_tree.nodes['Background'].inputs[1].default_value=.4;scene.world=world
floor=mat('Studio floor',(.055,.072,.09),.1,.42)
bpy.ops.mesh.primitive_plane_add(size=200,location=(0,0,-.006));plane=bpy.context.object;plane.name='STUDIO ONLY';plane.data.materials.append(floor)
def area(name,loc,power,size,target=(0,0,.5),scale=None):
 bpy.ops.object.light_add(type='AREA',location=loc);o=bpy.context.object;o.name=name;o.data.energy=power;o.data.shape='RECTANGLE';o.data.size=size;o.data.size_y=size*(.45 if scale is None else scale);o.rotation_euler=(Vector(target)-o.location).to_track_quat('-Z','Y').to_euler();return o
area('Large key softbox',(-3,-4,6),1300,6,scale=.65)
area('Long roof reflection',(0,1.5,6),1500,5,scale=.22)
area('Front fill',(-5,3,2.8),1000,4,scale=.7)
area('Rear rim',(4,0,4.5),1500,4,scale=.55)
bpy.ops.object.camera_add();cam=bpy.context.object;scene.camera=cam;cam.data.lens=58
scene.view_settings.view_transform='AgX'
views={
 'front_three_quarter':((-6.3,-5.8,3.0),(0,0,.59),58),
 'rear_three_quarter':((6.3,-5.5,2.65),(0,0,.62),58),
 'side':((0,-8,.68),(0,0,.68),'ORTHO'),
 'front':((-8,0,.65),(0,0,.65),'ORTHO'),
 'rear':((8,0,.65),(0,0,.65),'ORTHO'),
 'top':((0,0,9),(0,0,0),'ORTHO')}
for name,(pos,target,lens) in views.items():
 if os.environ.get('REVIEW_VIEWS') and name not in os.environ['REVIEW_VIEWS'].split(','):continue
 cam.location=pos;cam.rotation_euler=(Vector(target)-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.type='ORTHO' if lens=='ORTHO' else 'PERSP'
 if lens=='ORTHO':cam.data.ortho_scale=5.35 if name in ['side','top'] else 2.55
 else:cam.data.lens=lens
 if name in ['front','rear']:scene.render.resolution_x=1000;scene.render.resolution_y=850
 elif name=='top':scene.render.resolution_x=1600;scene.render.resolution_y=900
 else:scene.render.resolution_x=1600;scene.render.resolution_y=1000
 scene.render.filepath=OUT+'/'+name+'.png';bpy.ops.render.render(write_still=True)
print('REVIEW_MODEL_READY',meshcount,triangles)
