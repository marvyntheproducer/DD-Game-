# Silvia — blueprint study 01

Status: standalone approval model. Not integrated into Drift Drive. No game source files have been changed.

This review follows the visible silhouette and details in the supplied four-view drawing: wheelbase and overhangs, low coupe roof, front and rear glass, quarter windows, square lamp arrangement, deep bumper openings, raked side ducts, side skirts, five-spoke wheels and raised twin-mount rear wing. The neutral silver finish is for reviewing shape; the reference does not specify paint or material colours.

The drawing is a small, undimensioned raster image. Physical scale is inferred from its proportions; this is a visual reconstruction, not a dimension-certified CAD scan or a claim of perfect surface accuracy.

## Review

- `Silvia_Interactive_Review.html`: download and open in a WebGL-capable browser such as Chrome. Drag to rotate; scroll to zoom. Use the view buttons, wireframe button and the original drawing panel. Everything is embedded; no web server or internet connection is needed.
- `Silvia_Approval_Sheet.png`: rendered front/rear three-quarter, side, front, rear and top views, plus the supplied side drawing.
- `Silvia_Blueprint_Review.glb`: the actual 3D geometry used for the renders and interactive review.
- `Silvia_Blueprint_Review.blend`: editable source components in Blender.
- `build_silvia.py`: deterministic procedural source. Run with Blender 4.3 or newer, e.g. `blender -b -P build_silvia.py`. It exports the model and renders into a local `output` directory.

The preview asset batches repeated geometry by material and retains separate named wheel assemblies. Runtime LOD, wheel attachment, paint tuning and game integration remain pending visual approval.

Three.js r160 is used by the standalone viewer, under its included MIT licence. The source drawing was supplied by the user and remains unchanged.
